<?php
// Database configuration for standalone installation
// This file is created during installation

class Database {
    private static $instance = null;
    private $connection;
    
    private function __construct() {
        // Read configuration from settings table or environment
        $this->connect();
    }
    
    public static function getInstance() {
        if (self::$instance === null) {
            self::$instance = new Database();
        }
        return self::$instance;
    }
    
    private function connect() {
        try {
            // Check if installation is complete
            if (!$this->isInstalled()) {
                throw new Exception('Database not configured. Please run installation.');
            }
            
            $config = $this->getDbConfig();
            $dsn = $this->buildDsn($config);
            
            $this->connection = new PDO($dsn, $config['username'], $config['password'], [
                PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                PDO::ATTR_PERSISTENT => true
            ]);
            
        } catch (Exception $e) {
            throw new Exception('Database connection failed: ' . $e->getMessage());
        }
    }
    
    private function isInstalled() {
        // Check if config file exists or installation flag is set
        return file_exists(__DIR__ . '/installed.flag');
    }
    
    private function getDbConfig() {
        // In production, read from environment or config file
        // For security, never store credentials in code
        return [
            'type' => $_ENV['DB_TYPE'] ?? 'mysql',
            'host' => $_ENV['DB_HOST'] ?? 'localhost',
            'port' => $_ENV['DB_PORT'] ?? 3306,
            'database' => $_ENV['DB_NAME'] ?? '',
            'username' => $_ENV['DB_USER'] ?? '',
            'password' => $_ENV['DB_PASS'] ?? ''
        ];
    }
    
    private function buildDsn($config) {
        switch ($config['type']) {
            case 'mysql':
                return "mysql:host={$config['host']};port={$config['port']};dbname={$config['database']};charset=utf8mb4";
            case 'postgresql':
                return "pgsql:host={$config['host']};port={$config['port']};dbname={$config['database']}";
            case 'mssql':
                return "sqlsrv:Server={$config['host']},{$config['port']};Database={$config['database']}";
            default:
                throw new Exception('Unsupported database type');
        }
    }
    
    public function getConnection() {
        return $this->connection;
    }
    
    public function query($sql, $params = []) {
        $stmt = $this->connection->prepare($sql);
        $stmt->execute($params);
        return $stmt;
    }
}
?>