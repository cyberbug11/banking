<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    exit(0);
}

function checkPHPVersion() {
    $required = '8.0.0';
    $current = PHP_VERSION;
    return [
        'status' => version_compare($current, $required, '>='),
        'message' => $current,
        'required' => $required
    ];
}

function checkPDO() {
    return [
        'status' => extension_loaded('pdo'),
        'message' => extension_loaded('pdo') ? 'Installed' : 'Not installed'
    ];
}

function checkPDOMySQL() {
    return [
        'status' => extension_loaded('pdo_mysql'),
        'message' => extension_loaded('pdo_mysql') ? 'Installed' : 'Not installed'
    ];
}

function checkMbstring() {
    return [
        'status' => extension_loaded('mbstring'),
        'message' => extension_loaded('mbstring') ? 'Installed' : 'Not installed'
    ];
}

function checkJSON() {
    return [
        'status' => extension_loaded('json'),
        'message' => extension_loaded('json') ? 'Installed' : 'Not installed'
    ];
}

function checkWritePermissions() {
    $configDir = __DIR__ . '/../config';
    return [
        'status' => is_writable($configDir),
        'message' => is_writable($configDir) ? 'Writable' : 'Not writable',
        'path' => $configDir
    ];
}

function checkInstallationStatus() {
    $flagFile = __DIR__ . '/../config/installed.flag';
    return [
        'status' => !file_exists($flagFile),
        'message' => file_exists($flagFile) ? 'Already installed' : 'Not installed'
    ];
}

try {
    $checks = [
        'php_version' => checkPHPVersion(),
        'pdo' => checkPDO(),
        'pdo_mysql' => checkPDOMySQL(),
        'mbstring' => checkMbstring(),
        'json' => checkJSON(),
        'write_permissions' => checkWritePermissions(),
        'installation' => checkInstallationStatus()
    ];

    $allPassed = true;
    foreach ($checks as $key => $check) {
        if (!$check['status']) {
            $allPassed = false;
            break;
        }
    }

    echo json_encode([
        'success' => true,
        'checks' => $checks,
        'all_passed' => $allPassed,
        'server_software' => $_SERVER['SERVER_SOFTWARE'] ?? 'Unknown',
        'php_version' => PHP_VERSION
    ]);

} catch (Exception $e) {
    echo json_encode([
        'success' => false,
        'message' => 'System check failed: ' . $e->getMessage()
    ]);
}
?>
