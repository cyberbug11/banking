<?php
require_once '../config/database.php';
require_once '../classes/Auth.php';
require_once '../classes/AuditLogger.php';

header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, PUT, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    exit(0);
}

// Get token from Authorization header
$headers = getallheaders();
$token = null;

if (isset($headers['Authorization'])) {
    $token = str_replace('Bearer ', '', $headers['Authorization']);
}

if (!$token) {
    http_response_code(401);
    echo json_encode(['success' => false, 'message' => 'Authentication required']);
    exit;
}

try {
    $auth = new Auth();
    $user = $auth->getCurrentUser($token);
    
    if (!$user) {
        http_response_code(401);
        echo json_encode(['success' => false, 'message' => 'Invalid token']);
        exit;
    }
    
    $db = Database::getInstance()->getConnection();
    
    if ($_SERVER['REQUEST_METHOD'] === 'GET') {
        // Get user accounts
        $stmt = $db->prepare("
            SELECT ua.*, at.name as account_type_name
            FROM user_accounts ua
            LEFT JOIN account_types at ON ua.account_type_id = at.id
            WHERE ua.user_id = ?
            ORDER BY ua.created_at ASC
        ");
        $stmt->execute([$user['id']]);
        $accounts = $stmt->fetchAll();
        
        echo json_encode([
            'success' => true,
            'data' => $accounts
        ]);
        
    } elseif ($_SERVER['REQUEST_METHOD'] === 'POST') {
        // Create account (admin only)
        if (!in_array('admin', $user['roles'])) {
            http_response_code(403);
            echo json_encode(['success' => false, 'message' => 'Admin access required']);
            exit;
        }
        
        $input = json_decode(file_get_contents('php://input'), true);
        
        if (!$input || !isset($input['user_id']) || !isset($input['account_type'])) {
            echo json_encode(['success' => false, 'message' => 'Missing required fields']);
            exit;
        }
        
        try {
            // Generate account number
            $accountNumber = generateAccountNumber();
            $accountId = generateUuid();
            
            $stmt = $db->prepare("
                INSERT INTO user_accounts (
                    id, user_id, account_number, account_type, currency, 
                    balance, status, created_at, updated_at
                ) VALUES (?, ?, ?, ?, ?, 0.00, 'active', NOW(), NOW())
            ");
            
            $stmt->execute([
                $accountId,
                $input['user_id'],
                $accountNumber,
                $input['account_type'],
                $input['currency'] ?? 'USD'
            ]);
            
            // Log account creation
            $audit = new AuditLogger();
            $audit->log($user['id'], 'ACCOUNT_CREATED', 'user_accounts', $accountId, [
                'account_number' => $accountNumber,
                'account_type' => $input['account_type']
            ]);
            
            echo json_encode([
                'success' => true,
                'data' => [
                    'id' => $accountId,
                    'account_number' => $accountNumber
                ]
            ]);
            
        } catch (Exception $e) {
            echo json_encode(['success' => false, 'message' => 'Account creation failed: ' . $e->getMessage()]);
        }
    }
    
} catch (Exception $e) {
    echo json_encode(['success' => false, 'message' => 'Request failed: ' . $e->getMessage()]);
}

function generateAccountNumber() {
    // Generate a 10-digit account number
    return '1' . str_pad(mt_rand(0, 999999999), 9, '0', STR_PAD_LEFT);
}

function generateUuid() {
    return sprintf(
        '%04x%04x-%04x-%04x-%04x-%04x%04x%04x',
        mt_rand(0, 0xffff), mt_rand(0, 0xffff),
        mt_rand(0, 0xffff),
        mt_rand(0, 0x0fff) | 0x4000,
        mt_rand(0, 0x3fff) | 0x8000,
        mt_rand(0, 0xffff), mt_rand(0, 0xffff), mt_rand(0, 0xffff)
    );
}
?>