<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    exit(0);
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'message' => 'Method not allowed']);
    exit;
}

$input = json_decode(file_get_contents('php://input'), true);

if (!$input || !isset($input['type'])) {
    echo json_encode(['success' => false, 'message' => 'Invalid input']);
    exit;
}

$type = $input['type'];
$host = $input['host'] ?? 'localhost';
$port = $input['port'] ?? 3306;
$database = $input['database'] ?? '';
$username = $input['username'] ?? '';
$password = $input['password'] ?? '';

try {
    switch ($type) {
        case 'mysql':
            $dsn = "mysql:host=$host;port=$port;dbname=$database;charset=utf8mb4";
            break;
        case 'postgresql':
            $dsn = "pgsql:host=$host;port=$port;dbname=$database";
            break;
        case 'mssql':
            $dsn = "sqlsrv:Server=$host,$port;Database=$database";
            break;
        default:
            echo json_encode(['success' => false, 'message' => 'Unsupported database type']);
            exit;
    }

    $pdo = new PDO($dsn, $username, $password, [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_TIMEOUT => 5
    ]);

    // Test a simple query
    $stmt = $pdo->query('SELECT 1 as test');
    $result = $stmt->fetch();

    if ($result && $result['test'] == 1) {
        echo json_encode(['success' => true, 'message' => 'Database connection successful']);
    } else {
        echo json_encode(['success' => false, 'message' => 'Connection test failed']);
    }

} catch (PDOException $e) {
    echo json_encode(['success' => false, 'message' => 'Connection failed: ' . $e->getMessage()]);
} catch (Exception $e) {
    echo json_encode(['success' => false, 'message' => 'Error: ' . $e->getMessage()]);
}
?>