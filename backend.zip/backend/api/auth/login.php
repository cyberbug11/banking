<?php
require_once '../config/database.php';
require_once '../classes/Auth.php';
require_once '../classes/SecurityUtils.php';

header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    exit(0);
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'message' => 'Method not allowed']);
    exit;
}

$input = json_decode(file_get_contents('php://input'), true);

if (!$input || !isset($input['email']) || !isset($input['password'])) {
    echo json_encode(['success' => false, 'message' => 'Email and password are required']);
    exit;
}

// Rate limiting: max 5 attempts per 15 minutes per email
if (!SecurityUtils::checkRateLimit($input['email'], 'login', 5, 15)) {
    http_response_code(429);
    echo json_encode(['success' => false, 'message' => 'Too many login attempts. Please try again in 15 minutes.']);
    exit;
}

try {
    $auth = new Auth();
    $result = $auth->login($input['email'], $input['password']);
    
    if ($result['success']) {
        // Log successful login
        $audit = new AuditLogger();
        $audit->log($result['user']['id'], 'LOGIN_SUCCESS', 'user_sessions', null, [
            'ip_address' => $_SERVER['REMOTE_ADDR'] ?? null,
            'user_agent' => $_SERVER['HTTP_USER_AGENT'] ?? null
        ]);
    }
    
    echo json_encode($result);
    
} catch (Exception $e) {
    // Log detailed error server-side
    error_log('Login error: ' . $e->getMessage());
    // Return generic error to client
    echo json_encode(['success' => false, 'message' => 'Login failed. Please check your credentials.']);
}
?>