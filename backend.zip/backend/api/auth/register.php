<?php
require_once '../config/database.php';
require_once '../classes/Auth.php';
require_once '../classes/AuditLogger.php';

header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    exit(0);
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'message' => 'Method not allowed']);
    exit;
}

$input = json_decode(file_get_contents('php://input'), true);

if (!$input || !isset($input['email']) || !isset($input['password'])) {
    echo json_encode(['success' => false, 'message' => 'Email and password are required']);
    exit;
}

try {
    $auth = new Auth();
    $result = $auth->register($input['email'], $input['password'], $input['display_name'] ?? null);
    
    if ($result['success']) {
        // Log successful registration
        $audit = new AuditLogger();
        $audit->log($result['user_id'], 'USER_REGISTRATION', 'profiles', $result['user_id'], [
            'email' => $input['email'],
            'ip_address' => $_SERVER['REMOTE_ADDR'] ?? null
        ]);
    }
    
    echo json_encode($result);
    
} catch (Exception $e) {
    echo json_encode(['success' => false, 'message' => 'Registration failed: ' . $e->getMessage()]);
}
?>