<?php
require_once '../config/database.php';
require_once '../classes/Auth.php';

header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, PUT, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    exit(0);
}

// Get user ID from URL
$userId = $_GET['id'] ?? null;

if (!$userId) {
    echo json_encode(['success' => false, 'message' => 'User ID required']);
    exit;
}

// Get token from Authorization header
$headers = getallheaders();
$token = null;

if (isset($headers['Authorization'])) {
    $token = str_replace('Bearer ', '', $headers['Authorization']);
}

if (!$token) {
    http_response_code(401);
    echo json_encode(['success' => false, 'message' => 'Authentication required']);
    exit;
}

try {
    $auth = new Auth();
    $currentUser = $auth->getCurrentUser($token);
    
    if (!$currentUser) {
        http_response_code(401);
        echo json_encode(['success' => false, 'message' => 'Invalid token']);
        exit;
    }
    
    // Users can only access their own data unless they're admin
    if ($currentUser['id'] !== $userId && !in_array('admin', $currentUser['roles'])) {
        http_response_code(403);
        echo json_encode(['success' => false, 'message' => 'Access denied']);
        exit;
    }
    
    $db = Database::getInstance()->getConnection();
    
    if ($_SERVER['REQUEST_METHOD'] === 'GET') {
        $endpoint = $_GET['endpoint'] ?? 'profile';
        
        switch ($endpoint) {
            case 'profile':
                $stmt = $db->prepare("
                    SELECT p.*, uc.email, uc.email_verified
                    FROM profiles p
                    JOIN user_credentials uc ON p.user_id = uc.user_id
                    WHERE p.user_id = ?
                ");
                $stmt->execute([$userId]);
                $profile = $stmt->fetch();
                
                if (!$profile) {
                    http_response_code(404);
                    echo json_encode(['success' => false, 'message' => 'User not found']);
                    exit;
                }
                
                echo json_encode(['success' => true, 'data' => $profile]);
                break;
                
            case 'accounts':
                $stmt = $db->prepare("
                    SELECT ua.*, at.name as account_type_name
                    FROM user_accounts ua
                    LEFT JOIN account_types at ON ua.account_type_id = at.id
                    WHERE ua.user_id = ?
                ");
                $stmt->execute([$userId]);
                $accounts = $stmt->fetchAll();
                
                echo json_encode(['success' => true, 'data' => $accounts]);
                break;
                
            case 'roles':
                $stmt = $db->prepare("SELECT role FROM user_roles WHERE user_id = ?");
                $stmt->execute([$userId]);
                $roles = $stmt->fetchAll(PDO::FETCH_COLUMN);
                
                echo json_encode(['success' => true, 'data' => $roles]);
                break;
                
            default:
                echo json_encode(['success' => false, 'message' => 'Invalid endpoint']);
        }
        
    } elseif ($_SERVER['REQUEST_METHOD'] === 'PUT') {
        // Update user profile
        $input = json_decode(file_get_contents('php://input'), true);
        
        if (!$input) {
            echo json_encode(['success' => false, 'message' => 'Invalid input']);
            exit;
        }
        
        $allowedFields = ['display_name', 'phone', 'address', 'preferred_currency'];
        $updateFields = [];
        $updateValues = [];
        
        foreach ($allowedFields as $field) {
            if (isset($input[$field])) {
                $updateFields[] = "$field = ?";
                $updateValues[] = $input[$field];
            }
        }
        
        if (empty($updateFields)) {
            echo json_encode(['success' => false, 'message' => 'No valid fields to update']);
            exit;
        }
        
        $updateValues[] = $userId;
        
        $stmt = $db->prepare("
            UPDATE profiles 
            SET " . implode(', ', $updateFields) . ", updated_at = NOW()
            WHERE user_id = ?
        ");
        
        $stmt->execute($updateValues);
        
        echo json_encode(['success' => true, 'message' => 'Profile updated successfully']);
    }
    
} catch (Exception $e) {
    echo json_encode(['success' => false, 'message' => 'Request failed: ' . $e->getMessage()]);
}
?>