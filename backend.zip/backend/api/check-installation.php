<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    exit(0);
}

try {
    $flagFile = __DIR__ . '/../config/installed.flag';
    $isInstalled = file_exists($flagFile);
    
    echo json_encode([
        'success' => true,
        'installed' => $isInstalled,
        'timestamp' => $isInstalled ? filemtime($flagFile) : null
    ]);

} catch (Exception $e) {
    echo json_encode([
        'success' => false,
        'message' => 'Check failed: ' . $e->getMessage(),
        'installed' => false
    ]);
}
?>
