<?php
require_once '../config/database.php';
require_once '../classes/Auth.php';
require_once '../classes/AuditLogger.php';

header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    exit(0);
}

// Get token from Authorization header
$headers = getallheaders();
$token = null;

if (isset($headers['Authorization'])) {
    $token = str_replace('Bearer ', '', $headers['Authorization']);
}

if (!$token) {
    http_response_code(401);
    echo json_encode(['success' => false, 'message' => 'Authentication required']);
    exit;
}

try {
    $auth = new Auth();
    $user = $auth->getCurrentUser($token);
    
    if (!$user) {
        http_response_code(401);
        echo json_encode(['success' => false, 'message' => 'Invalid token']);
        exit;
    }
    
    $db = Database::getInstance()->getConnection();
    
    if ($_SERVER['REQUEST_METHOD'] === 'GET') {
        // Get user transactions
        $page = $_GET['page'] ?? 1;
        $limit = min($_GET['limit'] ?? 20, 100); // Max 100 per page
        $offset = ($page - 1) * $limit;
        
        $stmt = $db->prepare("
            SELECT t.*, ua.account_number
            FROM transactions t
            LEFT JOIN user_accounts ua ON t.account_id = ua.id
            WHERE t.user_id = ?
            ORDER BY t.created_at DESC
            LIMIT ? OFFSET ?
        ");
        $stmt->execute([$user['id'], $limit, $offset]);
        $transactions = $stmt->fetchAll();
        
        // Get total count
        $stmt = $db->prepare("SELECT COUNT(*) FROM transactions WHERE user_id = ?");
        $stmt->execute([$user['id']]);
        $total = $stmt->fetchColumn();
        
        echo json_encode([
            'success' => true,
            'data' => $transactions,
            'pagination' => [
                'page' => (int)$page,
                'limit' => (int)$limit,
                'total' => (int)$total,
                'pages' => ceil($total / $limit)
            ]
        ]);
        
    } elseif ($_SERVER['REQUEST_METHOD'] === 'POST') {
        // Create transaction (admin only)
        if (!in_array('admin', $user['roles'])) {
            http_response_code(403);
            echo json_encode(['success' => false, 'message' => 'Admin access required']);
            exit;
        }
        
        $input = json_decode(file_get_contents('php://input'), true);
        
        if (!$input || !isset($input['user_id']) || !isset($input['amount']) || !isset($input['transaction_type'])) {
            echo json_encode(['success' => false, 'message' => 'Missing required fields']);
            exit;
        }
        
        $db->beginTransaction();
        
        try {
            // Generate transaction ID and reference
            $transactionId = generateUuid();
            $referenceNumber = 'TXN' . date('YmdHis') . mt_rand(1000, 9999);
            
            // Insert transaction
            $stmt = $db->prepare("
                INSERT INTO transactions (
                    id, user_id, account_id, transaction_type, amount, 
                    description, reference_number, admin_id, created_at, updated_at
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, NOW(), NOW())
            ");
            
            $stmt->execute([
                $transactionId,
                $input['user_id'],
                $input['account_id'] ?? null,
                $input['transaction_type'],
                $input['amount'],
                $input['description'] ?? '',
                $referenceNumber,
                $user['id']
            ]);
            
            // Update account balance if account specified
            if (!empty($input['account_id'])) {
                $balanceChange = $input['transaction_type'] === 'credit' ? $input['amount'] : -$input['amount'];
                
                $stmt = $db->prepare("
                    UPDATE user_accounts 
                    SET balance = balance + ?, updated_at = NOW()
                    WHERE id = ?
                ");
                $stmt->execute([$balanceChange, $input['account_id']]);
            }
            
            $db->commit();
            
            // Log transaction
            $audit = new AuditLogger();
            $audit->logTransaction($user['id'], $transactionId, 'TRANSACTION_CREATED', $input['amount'], [
                'type' => $input['transaction_type'],
                'reference' => $referenceNumber
            ]);
            
            echo json_encode([
                'success' => true,
                'data' => [
                    'id' => $transactionId,
                    'reference_number' => $referenceNumber
                ]
            ]);
            
        } catch (Exception $e) {
            $db->rollBack();
            echo json_encode(['success' => false, 'message' => 'Transaction failed: ' . $e->getMessage()]);
        }
    }
    
} catch (Exception $e) {
    echo json_encode(['success' => false, 'message' => 'Request failed: ' . $e->getMessage()]);
}

function generateUuid() {
    return sprintf(
        '%04x%04x-%04x-%04x-%04x-%04x%04x%04x',
        mt_rand(0, 0xffff), mt_rand(0, 0xffff),
        mt_rand(0, 0xffff),
        mt_rand(0, 0x0fff) | 0x4000,
        mt_rand(0, 0x3fff) | 0x8000,
        mt_rand(0, 0xffff), mt_rand(0, 0xffff), mt_rand(0, 0xffff)
    );
}
?>