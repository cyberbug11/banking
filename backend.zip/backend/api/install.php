<?php
require_once __DIR__ . '/../classes/SecurityUtils.php';

header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    exit(0);
}

// Check if already installed
$flagFile = __DIR__ . '/../config/installed.flag';
if (file_exists($flagFile)) {
    http_response_code(403);
    echo json_encode(['success' => false, 'message' => 'Installation already completed. Delete config/installed.flag to reinstall.']);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'message' => 'Method not allowed']);
    exit;
}

$input = json_decode(file_get_contents('php://input'), true);

if (!$input || !isset($input['config']) || !isset($input['adminUser'])) {
    echo json_encode(['success' => false, 'message' => 'Invalid input']);
    exit;
}

$config = $input['config'];
$adminUser = $input['adminUser'];

// Validate admin user inputs
if (!SecurityUtils::validateEmail($adminUser['email'])) {
    echo json_encode(['success' => false, 'message' => 'Invalid email address']);
    exit;
}

if (!SecurityUtils::validatePassword($adminUser['password'])) {
    echo json_encode(['success' => false, 'message' => 'Password must be at least 8 characters with uppercase, lowercase, and number']);
    exit;
}

// Sanitize all inputs
$config['host'] = SecurityUtils::sanitizeInput($config['host']);
$config['database'] = SecurityUtils::sanitizeInput($config['database']);
$config['username'] = SecurityUtils::sanitizeInput($config['username']);
$adminUser['email'] = SecurityUtils::sanitizeInput($adminUser['email']);
$adminUser['displayName'] = SecurityUtils::sanitizeInput($adminUser['displayName']);

// Validate input lengths
if (strlen($adminUser['email']) > 255) {
    echo json_encode(['success' => false, 'message' => 'Email too long']);
    exit;
}

if (strlen($adminUser['displayName']) > 100) {
    echo json_encode(['success' => false, 'message' => 'Display name too long']);
    exit;
}

try {
    // Connect to database
    $type = $config['type'];
    $host = $config['host'];
    $port = $config['port'];
    $database = $config['database'];
    $username = $config['username'];
    $password = $config['password'];

    switch ($type) {
        case 'mysql':
            $dsn = "mysql:host=$host;port=$port;dbname=$database;charset=utf8mb4";
            break;
        case 'postgresql':
            $dsn = "pgsql:host=$host;port=$port;dbname=$database";
            break;
        case 'mssql':
            $dsn = "sqlsrv:Server=$host,$port;Database=$database";
            break;
        default:
            echo json_encode(['success' => false, 'message' => 'Unsupported database type']);
            exit;
    }

    $pdo = new PDO($dsn, $username, $password, [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC
    ]);

    // Read and execute schema
    $schemaFile = __DIR__ . "/../database/schema_{$type}.sql";
    if (!file_exists($schemaFile)) {
        echo json_encode(['success' => false, 'message' => "Schema file not found for $type"]);
        exit;
    }

    $schema = file_get_contents($schemaFile);
    $statements = explode(';', $schema);

    $pdo->beginTransaction();

    foreach ($statements as $statement) {
        $statement = trim($statement);
        if (!empty($statement)) {
            $pdo->exec($statement);
        }
    }

    // Create admin user
    $hashedPassword = password_hash($adminUser['password'], PASSWORD_DEFAULT);
    $userId = bin2hex(random_bytes(16)); // Generate UUID-like ID

    // Insert user profile
    $stmt = $pdo->prepare("
        INSERT INTO profiles (id, user_id, display_name, email, created_at, updated_at) 
        VALUES (?, ?, ?, ?, NOW(), NOW())
    ");
    $stmt->execute([$userId, $userId, $adminUser['displayName'], $adminUser['email']]);

    // Insert user credentials
    $stmt = $pdo->prepare("
        INSERT INTO user_credentials (user_id, email, password_hash, created_at, updated_at) 
        VALUES (?, ?, ?, NOW(), NOW())
    ");
    $stmt->execute([$userId, $adminUser['email'], $hashedPassword]);

    // Assign admin role
    $roleId = bin2hex(random_bytes(16));
    $stmt = $pdo->prepare("
        INSERT INTO user_roles (id, user_id, role, created_at) 
        VALUES (?, ?, 'admin', NOW())
    ");
    $stmt->execute([$roleId, $userId]);

    // Create default account type
    $accountTypeId = bin2hex(random_bytes(16));
    $stmt = $pdo->prepare("
        INSERT INTO account_types (id, name, description, minimum_balance, interest_rate, is_active, created_at, updated_at) 
        VALUES (?, 'Savings Account', 'Standard savings account', 0.00, 2.50, 1, NOW(), NOW())
    ");
    $stmt->execute([$accountTypeId]);

    // Create default currency
    $currencyId = bin2hex(random_bytes(16));
    $stmt = $pdo->prepare("
        INSERT INTO currencies (id, code, name, symbol, exchange_rate, is_default, is_active, created_at, updated_at) 
        VALUES (?, 'USD', 'US Dollar', '$', 1.0, 1, 1, NOW(), NOW())
    ");
    $stmt->execute([$currencyId]);

    // Save configuration
    $configData = [
        'db_type' => $type,
        'db_host' => $host,
        'db_port' => $port,
        'db_name' => $database,
        'installation_date' => date('Y-m-d H:i:s'),
        'version' => '1.0.0'
    ];

    $stmt = $pdo->prepare("
        INSERT INTO system_settings (id, setting_key, setting_value, created_at, updated_at) 
        VALUES 
        (?, 'installation_config', ?, NOW(), NOW()),
        (?, 'installation_complete', 'true', NOW(), NOW())
    ");
    $stmt->execute([
        bin2hex(random_bytes(16)), 
        json_encode($configData),
        bin2hex(random_bytes(16))
    ]);

    $pdo->commit();

    // Create installation flag file
    $flagFile = __DIR__ . '/../config/installed.flag';
    file_put_contents($flagFile, json_encode([
        'installed_at' => date('Y-m-d H:i:s'),
        'version' => '1.0.0',
        'admin_email' => $adminUser['email']
    ]));

    // Create .env file with database credentials (for future reference)
    $envFile = __DIR__ . '/../../.env.local';
    $envContent = "# Database Configuration - Generated during installation\n";
    $envContent .= "DB_TYPE={$type}\n";
    $envContent .= "DB_HOST={$host}\n";
    $envContent .= "DB_PORT={$port}\n";
    $envContent .= "DB_NAME={$database}\n";
    $envContent .= "DB_USER={$username}\n";
    $envContent .= "DB_PASS={$password}\n";
    $envContent .= "INSTALLATION_DATE=" . date('Y-m-d H:i:s') . "\n";
    file_put_contents($envFile, $envContent);

    echo json_encode([
        'success' => true, 
        'message' => 'Installation completed successfully',
        'admin_id' => $userId,
        'redirect' => '/login'
    ]);

} catch (PDOException $e) {
    if (isset($pdo)) {
        $pdo->rollBack();
    }
    // Log detailed error server-side
    error_log('Installation database error: ' . $e->getMessage());
    // Return generic error to client
    echo json_encode(['success' => false, 'message' => 'Database connection or setup failed. Please check your database credentials.']);
} catch (Exception $e) {
    if (isset($pdo)) {
        $pdo->rollBack();
    }
    // Log detailed error server-side
    error_log('Installation error: ' . $e->getMessage());
    // Return generic error to client
    echo json_encode(['success' => false, 'message' => 'Installation failed. Please check server logs for details.']);
}
?>