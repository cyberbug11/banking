<?php
// Security headers
header('X-Content-Type-Options: nosniff');
header('X-Frame-Options: DENY');
header('X-XSS-Protection: 1; mode=block');
header('Strict-Transport-Security: max-age=31536000; includeSubDomains');

class SecurityUtils {
    
    public static function sanitizeInput($input) {
        if (is_array($input)) {
            return array_map([self::class, 'sanitizeInput'], $input);
        }
        
        // Remove dangerous characters and patterns
        $input = htmlspecialchars($input, ENT_QUOTES, 'UTF-8');
        $input = preg_replace('/[<>"\']/', '', $input);
        
        // Remove SQL injection patterns
        $patterns = [
            '/(\b(SELECT|INSERT|UPDATE|DELETE|DROP|UNION|CREATE|ALTER|EXEC|EXECUTE)\b)/i',
            '/(--|\#|\/\*|\*\/)/i',
            '/(\bOR\b|\bAND\b)\s+\d+\s*=\s*\d+/i'
        ];
        
        foreach ($patterns as $pattern) {
            $input = preg_replace($pattern, '', $input);
        }
        
        return trim($input);
    }
    
    public static function validateToken($token) {
        if (!$token || !is_string($token)) {
            return false;
        }
        
        // Basic token format validation
        if (strlen($token) < 32 || strlen($token) > 255) {
            return false;
        }
        
        // Check for valid characters only
        if (!preg_match('/^[a-zA-Z0-9+\/=]+$/', $token)) {
            return false;
        }
        
        return true;
    }
    
    public static function checkRateLimit($userId, $action, $maxAttempts = 10, $windowMinutes = 60) {
        try {
            $db = Database::getInstance()->getConnection();
            
            $windowStart = date('Y-m-d H:i:00', strtotime("-$windowMinutes minutes"));
            
            // Clean old rate limit records
            $stmt = $db->prepare("DELETE FROM rate_limits WHERE window_start < ?");
            $stmt->execute([date('Y-m-d H:i:00', strtotime('-24 hours'))]);
            
            // Check current rate
            $stmt = $db->prepare("
                SELECT SUM(action_count) as total_attempts
                FROM rate_limits 
                WHERE user_id = ? AND action_type = ? AND window_start >= ?
            ");
            $stmt->execute([$userId, $action, $windowStart]);
            $result = $stmt->fetch();
            
            $currentAttempts = $result['total_attempts'] ?? 0;
            
            if ($currentAttempts >= $maxAttempts) {
                // Log rate limit violation
                $audit = new AuditLogger();
                $audit->logSecurityEvent($userId, 'RATE_LIMIT_EXCEEDED', [
                    'action' => $action,
                    'attempts' => $currentAttempts,
                    'max_attempts' => $maxAttempts
                ]);
                
                return false;
            }
            
            // Record this attempt
            $currentWindow = date('Y-m-d H:i:00');
            $stmt = $db->prepare("
                INSERT INTO rate_limits (id, user_id, action_type, window_start, action_count, created_at)
                VALUES (?, ?, ?, ?, 1, NOW())
                ON DUPLICATE KEY UPDATE action_count = action_count + 1
            ");
            
            $stmt->execute([
                self::generateUuid(),
                $userId,
                $action,
                $currentWindow
            ]);
            
            return true;
            
        } catch (Exception $e) {
            // On error, allow the action but log the issue
            error_log("Rate limit check failed: " . $e->getMessage());
            return true;
        }
    }
    
    public static function validateEmail($email) {
        return filter_var($email, FILTER_VALIDATE_EMAIL) !== false;
    }
    
    public static function validatePassword($password) {
        // At least 8 characters, one uppercase, one lowercase, one number
        return strlen($password) >= 8 &&
               preg_match('/[A-Z]/', $password) &&
               preg_match('/[a-z]/', $password) &&
               preg_match('/[0-9]/', $password);
    }
    
    public static function hashPassword($password) {
        return password_hash($password, PASSWORD_ARGON2ID, [
            'memory_cost' => 65536, // 64 MB
            'time_cost' => 4,       // 4 iterations
            'threads' => 3          // 3 threads
        ]);
    }
    
    public static function generateSecureToken($length = 32) {
        return bin2hex(random_bytes($length));
    }
    
    public static function logSecurityEvent($userId, $event, $details = []) {
        try {
            $audit = new AuditLogger();
            $audit->logSecurityEvent($userId, $event, array_merge($details, [
                'ip_address' => $_SERVER['REMOTE_ADDR'] ?? 'unknown',
                'user_agent' => $_SERVER['HTTP_USER_AGENT'] ?? 'unknown',
                'timestamp' => date('Y-m-d H:i:s')
            ]));
        } catch (Exception $e) {
            error_log("Security logging failed: " . $e->getMessage());
        }
    }
    
    private static function generateUuid() {
        return sprintf(
            '%04x%04x-%04x-%04x-%04x-%04x%04x%04x',
            mt_rand(0, 0xffff), mt_rand(0, 0xffff),
            mt_rand(0, 0xffff),
            mt_rand(0, 0x0fff) | 0x4000,
            mt_rand(0, 0x3fff) | 0x8000,
            mt_rand(0, 0xffff), mt_rand(0, 0xffff), mt_rand(0, 0xffff)
        );
    }
}

// CORS configuration
function handleCORS() {
    $allowedOrigins = [
        'http://localhost:5173',
        'http://localhost:3000',
        'https://yourdomain.com'
    ];
    
    $origin = $_SERVER['HTTP_ORIGIN'] ?? '';
    
    if (in_array($origin, $allowedOrigins)) {
        header("Access-Control-Allow-Origin: $origin");
    }
    
    header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS');
    header('Access-Control-Allow-Headers: Content-Type, Authorization');
    header('Access-Control-Allow-Credentials: true');
}

// Apply CORS to all API requests
handleCORS();
?>