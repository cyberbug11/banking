<?php
require_once '../config/database.php';

class AuditLogger {
    private $db;
    
    public function __construct() {
        $this->db = Database::getInstance()->getConnection();
    }
    
    public function log($userId, $action, $tableName, $recordId = null, $data = []) {
        try {
            $stmt = $this->db->prepare("
                INSERT INTO audit_logs (
                    id, user_id, action, table_name, record_id, 
                    new_values, ip_address, user_agent, created_at
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, NOW())
            ");
            
            $stmt->execute([
                $this->generateUuid(),
                $userId,
                $action,
                $tableName,
                $recordId,
                json_encode($data),
                $_SERVER['REMOTE_ADDR'] ?? null,
                $_SERVER['HTTP_USER_AGENT'] ?? null
            ]);
            
        } catch (Exception $e) {
            // Log errors but don't throw to avoid breaking main functionality
            error_log("Audit log failed: " . $e->getMessage());
        }
    }
    
    public function logSecurityEvent($userId, $eventType, $details = []) {
        $this->log($userId, "SECURITY_EVENT", "security", null, [
            'event_type' => $eventType,
            'details' => $details
        ]);
    }
    
    public function logTransaction($userId, $transactionId, $action, $amount, $details = []) {
        $this->log($userId, $action, "transactions", $transactionId, [
            'amount' => $amount,
            'details' => $details
        ]);
    }
    
    private function generateUuid() {
        return sprintf(
            '%04x%04x-%04x-%04x-%04x-%04x%04x%04x',
            mt_rand(0, 0xffff), mt_rand(0, 0xffff),
            mt_rand(0, 0xffff),
            mt_rand(0, 0x0fff) | 0x4000,
            mt_rand(0, 0x3fff) | 0x8000,
            mt_rand(0, 0xffff), mt_rand(0, 0xffff), mt_rand(0, 0xffff)
        );
    }
}
?>