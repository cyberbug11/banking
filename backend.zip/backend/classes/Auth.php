<?php
require_once '../config/database.php';

class Auth {
    private $db;
    
    public function __construct() {
        $this->db = Database::getInstance()->getConnection();
    }
    
    public function login($email, $password) {
        try {
            // Get user credentials
            $stmt = $this->db->prepare("
                SELECT uc.user_id, uc.email, uc.password_hash, uc.email_verified,
                       p.display_name, p.avatar_url, p.phone, p.address
                FROM user_credentials uc
                JOIN profiles p ON uc.user_id = p.user_id
                WHERE uc.email = ? AND p.id IS NOT NULL
            ");
            $stmt->execute([$email]);
            $user = $stmt->fetch();
            
            if (!$user || !password_verify($password, $user['password_hash'])) {
                return ['success' => false, 'message' => 'Invalid email or password'];
            }
            
            if (!$user['email_verified']) {
                return ['success' => false, 'message' => 'Please verify your email before logging in'];
            }
            
            // Get user roles
            $stmt = $this->db->prepare("SELECT role FROM user_roles WHERE user_id = ?");
            $stmt->execute([$user['user_id']]);
            $roles = $stmt->fetchAll(PDO::FETCH_COLUMN);
            
            // Get user accounts
            $stmt = $this->db->prepare("
                SELECT id, account_number, account_type, balance, currency, status
                FROM user_accounts 
                WHERE user_id = ? AND status = 'active'
            ");
            $stmt->execute([$user['user_id']]);
            $accounts = $stmt->fetchAll();
            
            // Create session
            $sessionToken = $this->createSession($user['user_id']);
            
            return [
                'success' => true,
                'user' => [
                    'id' => $user['user_id'],
                    'email' => $user['email'],
                    'profile' => [
                        'display_name' => $user['display_name'],
                        'avatar_url' => $user['avatar_url'],
                        'phone' => $user['phone'],
                        'address' => $user['address']
                    ],
                    'accounts' => $accounts,
                    'roles' => $roles
                ],
                'token' => $sessionToken
            ];
            
        } catch (Exception $e) {
            return ['success' => false, 'message' => 'Login failed: ' . $e->getMessage()];
        }
    }
    
    public function register($email, $password, $displayName = null) {
        try {
            // Check if user already exists
            $stmt = $this->db->prepare("SELECT id FROM user_credentials WHERE email = ?");
            $stmt->execute([$email]);
            if ($stmt->fetch()) {
                return ['success' => false, 'message' => 'Email already registered'];
            }
            
            $this->db->beginTransaction();
            
            // Generate user ID
            $userId = $this->generateUuid();
            
            // Create profile
            $stmt = $this->db->prepare("
                INSERT INTO profiles (id, user_id, display_name, email, created_at, updated_at)
                VALUES (?, ?, ?, ?, NOW(), NOW())
            ");
            $stmt->execute([$userId, $userId, $displayName ?: 'User', $email]);
            
            // Create credentials
            $passwordHash = password_hash($password, PASSWORD_DEFAULT);
            $stmt = $this->db->prepare("
                INSERT INTO user_credentials (user_id, email, password_hash, email_verified, created_at, updated_at)
                VALUES (?, ?, ?, TRUE, NOW(), NOW())
            ");
            $stmt->execute([$userId, $email, $passwordHash]);
            
            // Assign customer role
            $stmt = $this->db->prepare("
                INSERT INTO user_roles (id, user_id, role, created_at)
                VALUES (?, ?, 'customer', NOW())
            ");
            $stmt->execute([$this->generateUuid(), $userId]);
            
            $this->db->commit();
            
            return [
                'success' => true,
                'message' => 'Registration successful! You can now log in.',
                'user_id' => $userId
            ];
            
        } catch (Exception $e) {
            $this->db->rollBack();
            return ['success' => false, 'message' => 'Registration failed: ' . $e->getMessage()];
        }
    }
    
    public function verifyToken($token) {
        try {
            $stmt = $this->db->prepare("
                SELECT us.user_id, p.email, p.display_name, p.avatar_url, p.phone, p.address
                FROM user_sessions us
                JOIN profiles p ON us.user_id = p.user_id
                WHERE us.session_token = ? AND us.expires_at > NOW()
            ");
            $stmt->execute([$token]);
            $session = $stmt->fetch();
            
            if (!$session) {
                return ['success' => false, 'message' => 'Invalid or expired token'];
            }
            
            // Update last activity
            $stmt = $this->db->prepare("
                UPDATE user_sessions 
                SET last_activity = NOW() 
                WHERE session_token = ?
            ");
            $stmt->execute([$token]);
            
            // Get user roles
            $stmt = $this->db->prepare("SELECT role FROM user_roles WHERE user_id = ?");
            $stmt->execute([$session['user_id']]);
            $roles = $stmt->fetchAll(PDO::FETCH_COLUMN);
            
            // Get user accounts
            $stmt = $this->db->prepare("
                SELECT id, account_number, account_type, balance, currency, status
                FROM user_accounts 
                WHERE user_id = ? AND status = 'active'
            ");
            $stmt->execute([$session['user_id']]);
            $accounts = $stmt->fetchAll();
            
            return [
                'success' => true,
                'user' => [
                    'id' => $session['user_id'],
                    'email' => $session['email'],
                    'profile' => [
                        'display_name' => $session['display_name'],
                        'avatar_url' => $session['avatar_url'],
                        'phone' => $session['phone'],
                        'address' => $session['address']
                    ],
                    'roles' => $roles,
                    'accounts' => $accounts
                ]
            ];
            
        } catch (Exception $e) {
            return ['success' => false, 'message' => 'Token verification failed'];
        }
    }
    
    public function logout($token) {
        try {
            $stmt = $this->db->prepare("DELETE FROM user_sessions WHERE session_token = ?");
            $stmt->execute([$token]);
            return ['success' => true, 'message' => 'Logged out successfully'];
        } catch (Exception $e) {
            return ['success' => false, 'message' => 'Logout failed'];
        }
    }
    
    private function createSession($userId) {
        $sessionToken = bin2hex(random_bytes(32));
        $expiresAt = date('Y-m-d H:i:s', strtotime('+24 hours'));
        
        $stmt = $this->db->prepare("
            INSERT INTO user_sessions (id, user_id, session_token, ip_address, user_agent, expires_at, created_at)
            VALUES (?, ?, ?, ?, ?, ?, NOW())
        ");
        
        $stmt->execute([
            $this->generateUuid(),
            $userId,
            $sessionToken,
            $_SERVER['REMOTE_ADDR'] ?? null,
            $_SERVER['HTTP_USER_AGENT'] ?? null,
            $expiresAt
        ]);
        
        return $sessionToken;
    }
    
    private function generateUuid() {
        return sprintf(
            '%04x%04x-%04x-%04x-%04x-%04x%04x%04x',
            mt_rand(0, 0xffff), mt_rand(0, 0xffff),
            mt_rand(0, 0xffff),
            mt_rand(0, 0x0fff) | 0x4000,
            mt_rand(0, 0x3fff) | 0x8000,
            mt_rand(0, 0xffff), mt_rand(0, 0xffff), mt_rand(0, 0xffff)
        );
    }
    
    public function hasRole($userId, $role) {
        $stmt = $this->db->prepare("SELECT id FROM user_roles WHERE user_id = ? AND role = ?");
        $stmt->execute([$userId, $role]);
        return $stmt->fetch() !== false;
    }
    
    public function getCurrentUser($token) {
        $result = $this->verifyToken($token);
        if (!$result['success']) {
            return null;
        }
        
        $userId = $result['user']['id'];
        
        // Get full user data
        $stmt = $this->db->prepare("
            SELECT p.*, uc.email, uc.email_verified
            FROM profiles p
            JOIN user_credentials uc ON p.user_id = uc.user_id
            WHERE p.user_id = ?
        ");
        $stmt->execute([$userId]);
        $profile = $stmt->fetch();
        
        // Get roles
        $stmt = $this->db->prepare("SELECT role FROM user_roles WHERE user_id = ?");
        $stmt->execute([$userId]);
        $roles = $stmt->fetchAll(PDO::FETCH_COLUMN);
        
        // Get accounts
        $stmt = $this->db->prepare("
            SELECT id, account_number, account_type, balance, currency, status
            FROM user_accounts 
            WHERE user_id = ?
        ");
        $stmt->execute([$userId]);
        $accounts = $stmt->fetchAll();
        
        return [
            'id' => $userId,
            'email' => $profile['email'],
            'profile' => $profile,
            'roles' => $roles,
            'accounts' => $accounts
        ];
    }
}
?>